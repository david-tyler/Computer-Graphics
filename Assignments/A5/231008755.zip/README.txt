David-Tyler Ighedosa, UIN: 231008755, ighedosadt@tamu.edu

Completed everything

For Task 6:
In the tfrag.glsl fragment shader set the last: gl_FragColor.rgb = result.rgb to just gl_FragColor.rgb = pos; or
gl_FragColor.rgb = nor; or
gl_FragColor.rgb = ke; or
gl_FragColor.rgb = kd;
And run the program and that will generate the 4 textures.

Use ctrl + hold mouse click to zoom like the regular camera from A3. You also move the camera around by holding mouse click and dragging the mouse like before.

Press space to toggle all of the movement and stuff
Press b toggle on or off blur mode