David-Tyler Ighedosa, UIN: 231008755, ighedosadt@tamu.edu

Completed up to Tasks 1 through 4 and Task 6
